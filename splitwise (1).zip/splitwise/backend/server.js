// server.js
// The web server. It does two jobs:
//   1. Serves the frontend files (HTML/CSS/JS) from the /public folder.
//   2. Exposes a REST API that the frontend calls to read/write data.
//
// A REST API is just a set of URLs the frontend can request. Each URL +
// HTTP method (GET/POST/DELETE) maps to an action on the database.

const express = require("express");
const path = require("path");
const db = require("./db");
const { computeBalances, simplifyDebts } = require("./balances");

const app = express();
const PORT = 3000;

// Middleware: lets the server read JSON sent in request bodies.
app.use(express.json());
// Serve everything in /public as static files (index.html, app.js, etc).
app.use(express.static(path.join(__dirname, "..", "public")));

// node:sqlite returns INTEGER ids as BigInt. This helper converts them
// to normal numbers so they serialize cleanly to JSON.
function num(v) {
  return typeof v === "bigint" ? Number(v) : v;
}

// --- Helper: load everything needed to compute a group's state --------
function loadGroupData(groupId) {
  const members = db
    .prepare("SELECT * FROM members WHERE group_id = ?")
    .all(groupId);
  const expenses = db
    .prepare("SELECT * FROM expenses WHERE group_id = ?")
    .all(groupId);
  const expenseSplits = db
    .prepare(
      `SELECT es.* FROM expense_splits es
       JOIN expenses e ON e.id = es.expense_id
       WHERE e.group_id = ?`
    )
    .all(groupId);
  const settlements = db
    .prepare("SELECT * FROM settlements WHERE group_id = ?")
    .all(groupId);
  return { members, expenses, expenseSplits, settlements };
}

// ====================================================================
//  GROUPS
// ====================================================================

// Create a group. Body: { name }
app.post("/api/groups", (req, res) => {
  const { name } = req.body;
  if (!name) return res.status(400).json({ error: "name is required" });
  const info = db.prepare("INSERT INTO groups (name) VALUES (?)").run(name);
  res.json({ id: num(info.lastInsertRowid), name });
});

// List all groups.
app.get("/api/groups", (req, res) => {
  const groups = db.prepare("SELECT * FROM groups ORDER BY id DESC").all();
  res.json(groups);
});

// ====================================================================
//  MEMBERS
// ====================================================================

// Add a member to a group. Body: { name }
app.post("/api/groups/:groupId/members", (req, res) => {
  const groupId = Number(req.params.groupId);
  const { name } = req.body;
  if (!name) return res.status(400).json({ error: "name is required" });
  const info = db
    .prepare("INSERT INTO members (group_id, name) VALUES (?, ?)")
    .run(groupId, name);
  res.json({ id: num(info.lastInsertRowid), group_id: groupId, name });
});

// ====================================================================
//  EXPENSES
// ====================================================================

// Given the split mode and the raw input, work out exactly how much each
// person owes. Returns { splits: [{memberId, amountOwed}], error }.
//
// Four modes are supported:
//   "equal"   -> splitAmong: [memberId, ...]           divide amount evenly
//   "exact"   -> splits: [{memberId, amount}, ...]      use amounts as-is
//   "percent" -> splits: [{memberId, percent}, ...]     divide by percentage
//   "shares"  -> splits: [{memberId, shares}, ...]      divide by share weight
function buildSplits(mode, amount, body) {
  if (mode === "exact") {
    const rows = body.splits;
    if (!Array.isArray(rows) || rows.length === 0) {
      return { error: "exact split needs a splits array" };
    }
    let total = 0;
    const splits = rows.map((r) => {
      total += Number(r.amount);
      return { memberId: Number(r.memberId), amountOwed: Number(r.amount) };
    });
    // The exact amounts must add up to the expense total (allow 1 paisa of
    // rounding slack).
    if (Math.abs(total - amount) > 0.01) {
      return { error: `exact amounts add up to ${total.toFixed(2)}, but the expense is ${amount.toFixed(2)}` };
    }
    return { splits };
  }

  if (mode === "percent") {
    const rows = body.splits;
    if (!Array.isArray(rows) || rows.length === 0) {
      return { error: "percent split needs a splits array" };
    }
    const totalPct = rows.reduce((sum, r) => sum + Number(r.percent), 0);
    // Percentages must add up to 100 (allow tiny rounding slack).
    if (Math.abs(totalPct - 100) > 0.01) {
      return { error: `percentages add up to ${totalPct}%, but must total 100%` };
    }
    const splits = rows.map((r) => ({
      memberId: Number(r.memberId),
      amountOwed: Math.round((amount * Number(r.percent)) / 100 * 100) / 100,
    }));
    return { splits };
  }

  if (mode === "shares") {
    const rows = body.splits;
    if (!Array.isArray(rows) || rows.length === 0) {
      return { error: "shares split needs a splits array" };
    }
    const totalShares = rows.reduce((sum, r) => sum + Number(r.shares), 0);
    if (totalShares <= 0) {
      return { error: "total shares must be greater than zero" };
    }
    // Each person owes (their shares / total shares) of the amount.
    const splits = rows.map((r) => ({
      memberId: Number(r.memberId),
      amountOwed: Math.round((amount * Number(r.shares)) / totalShares * 100) / 100,
    }));
    return { splits };
  }

  // Default: equal split.
  const ids = body.splitAmong;
  if (!Array.isArray(ids) || ids.length === 0) {
    return { error: "equal split needs a splitAmong array" };
  }
  const share = Math.round((amount / ids.length) * 100) / 100;
  const splits = ids.map((memberId) => ({ memberId: Number(memberId), amountOwed: share }));
  return { splits };
}

// Add an expense. Body:
//   { description, amount, paidBy, splitType, ...split input }
// splitType is "equal" (default), "exact", or "shares". See buildSplits above
// for the shape of the split input each mode expects.
app.post("/api/groups/:groupId/expenses", (req, res) => {
  const groupId = Number(req.params.groupId);
  const { description, amount, paidBy, splitType = "equal" } = req.body;

  if (!description || !amount || !paidBy) {
    return res.status(400).json({ error: "description, amount and paidBy are required" });
  }

  // Turn the split input into concrete per-person amounts.
  const { splits, error } = buildSplits(splitType, Number(amount), req.body);
  if (error) return res.status(400).json({ error });

  const insertExpense = db.prepare(
    "INSERT INTO expenses (group_id, description, amount, paid_by) VALUES (?, ?, ?, ?)"
  );
  const insertSplit = db.prepare(
    "INSERT INTO expense_splits (expense_id, member_id, amount_owed) VALUES (?, ?, ?)"
  );

  // A transaction ensures the expense and its splits are saved together
  // (all-or-nothing). If any part fails, nothing is written.
  db.exec("BEGIN");
  try {
    const info = insertExpense.run(groupId, description, amount, paidBy);
    const expenseId = num(info.lastInsertRowid);
    splits.forEach((s) => {
      insertSplit.run(expenseId, s.memberId, s.amountOwed);
    });
    db.exec("COMMIT");
    res.json({ id: expenseId, description, amount, paid_by: paidBy });
  } catch (err) {
    db.exec("ROLLBACK");
    res.status(500).json({ error: "failed to save expense" });
  }
});

// Delete an expense (its splits are removed automatically via CASCADE).
app.delete("/api/expenses/:expenseId", (req, res) => {
  db.prepare("DELETE FROM expenses WHERE id = ?").run(Number(req.params.expenseId));
  res.json({ ok: true });
});

// ====================================================================
//  SETTLEMENTS
// ====================================================================

// Record a payment. Body: { paidBy, paidTo, amount }
app.post("/api/groups/:groupId/settlements", (req, res) => {
  const groupId = Number(req.params.groupId);
  const { paidBy, paidTo, amount } = req.body;
  if (!paidBy || !paidTo || !amount) {
    return res.status(400).json({ error: "paidBy, paidTo and amount are required" });
  }
  const info = db
    .prepare(
      "INSERT INTO settlements (group_id, paid_by, paid_to, amount) VALUES (?, ?, ?, ?)"
    )
    .run(groupId, paidBy, paidTo, amount);
  res.json({ id: num(info.lastInsertRowid) });
});

// ====================================================================
//  GROUP STATE (members + expenses + balances + settle-up plan)
// ====================================================================

// The frontend calls this to render everything about a group at once.
app.get("/api/groups/:groupId/state", (req, res) => {
  const groupId = Number(req.params.groupId);
  const { members, expenses, expenseSplits, settlements } = loadGroupData(groupId);

  // Attach the list of split member-ids onto each expense for display.
  const splitsByExpense = {};
  expenseSplits.forEach((s) => {
    (splitsByExpense[s.expense_id] ||= []).push(s.member_id);
  });
  const expensesOut = expenses.map((e) => ({
    ...e,
    splitAmong: splitsByExpense[e.id] || [],
  }));

  const balance = computeBalances(members, expenseSplits, expenses, settlements);
  const settleUp = simplifyDebts(balance);

  res.json({
    members,
    expenses: expensesOut,
    balances: balance,
    settleUp,
  });
});

// ====================================================================
//  DASHBOARD (cross-group summary for one person)
// ====================================================================

// The dashboard needs a notion of "you" to show "you are owed" vs "you owe".
// Since there's no login, the frontend passes ?name=... to say who is viewing.
// We match that person by name within each group and total up their position.
//
// Returns:
//   { youAreOwed, youOwe, totalBalance, totalExpensesThisMonth,
//     groups: [{ id, name, memberCount, yourBalance }],
//     recentExpenses: [...], recentActivity: [...] }
app.get("/api/dashboard", (req, res) => {
  const viewerName = (req.query.name || "").trim();
  const groups = db.prepare("SELECT * FROM groups ORDER BY id DESC").all();

  let youAreOwed = 0;
  let youOwe = 0;
  const groupsOut = [];
  const allExpenses = [];

  const monthPrefix = new Date().toISOString().slice(0, 7); // "YYYY-MM"
  let totalExpensesThisMonth = 0;

  for (const g of groups) {
    const { members, expenses, expenseSplits, settlements } = loadGroupData(g.id);
    const balance = computeBalances(members, expenseSplits, expenses, settlements);

    // Find the viewer within this group by name (if present).
    const me = members.find((m) => m.name === viewerName);
    const yourBalance = me ? Math.round((balance[me.id] || 0) * 100) / 100 : 0;
    if (yourBalance > 0) youAreOwed += yourBalance;
    else if (yourBalance < 0) youOwe += -yourBalance;

    groupsOut.push({
      id: g.id,
      name: g.name,
      memberCount: members.length,
      yourBalance,
      inGroup: !!me,
    });

    // Collect expenses for the recent feed, tagged with group + payer name.
    const nameById = {};
    members.forEach((m) => (nameById[m.id] = m.name));
    expenses.forEach((e) => {
      if ((e.created_at || "").startsWith(monthPrefix)) {
        totalExpensesThisMonth += e.amount;
      }
      allExpenses.push({
        id: e.id,
        description: e.description,
        amount: e.amount,
        groupName: g.name,
        paidByName: nameById[e.paid_by] || "?",
        splitCount: expenseSplits.filter((s) => s.expense_id === e.id).length,
        created_at: e.created_at,
      });
    });
  }

  // Most recent expenses across all groups.
  allExpenses.sort((a, b) => (b.created_at || "").localeCompare(a.created_at || ""));

  res.json({
    youAreOwed: Math.round(youAreOwed * 100) / 100,
    youOwe: Math.round(youOwe * 100) / 100,
    totalBalance: Math.round((youAreOwed - youOwe) * 100) / 100,
    totalExpensesThisMonth: Math.round(totalExpensesThisMonth * 100) / 100,
    groups: groupsOut,
    recentExpenses: allExpenses.slice(0, 8),
  });
});

// List all members across all groups, unique by name - used to populate
// the "who are you?" viewer picker on the dashboard.
app.get("/api/people", (req, res) => {
  const rows = db.prepare("SELECT DISTINCT name FROM members ORDER BY name").all();
  res.json(rows.map((r) => r.name));
});

app.listen(PORT, () => {
  console.log(`Splitwise clone running at http://localhost:${PORT}`);
});
