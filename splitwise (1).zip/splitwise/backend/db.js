// db.js
// Sets up the SQLite database and creates all tables if they don't exist.
//
// We use node:sqlite, which is BUILT INTO Node.js (v22.5+). That means
// no extra install, no compiling - it just works. SQLite stores the whole
// database in a single file (splitwise.db) with no separate server.

const { DatabaseSync } = require("node:sqlite");
const path = require("path");

// The database file lives next to this script. Created automatically
// if it doesn't exist.
const db = new DatabaseSync(path.join(__dirname, "splitwise.db"));

// Enforce foreign key relationships (off by default in SQLite).
db.exec("PRAGMA foreign_keys = ON;");

// --- Schema -----------------------------------------------------------
// "IF NOT EXISTS" means running this again won't wipe or duplicate data.

db.exec(`
  CREATE TABLE IF NOT EXISTS groups (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    name        TEXT NOT NULL,
    created_at  TEXT NOT NULL DEFAULT (datetime('now'))
  );

  CREATE TABLE IF NOT EXISTS members (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    group_id    INTEGER NOT NULL,
    name        TEXT NOT NULL,
    FOREIGN KEY (group_id) REFERENCES groups(id) ON DELETE CASCADE
  );

  CREATE TABLE IF NOT EXISTS expenses (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    group_id    INTEGER NOT NULL,
    description TEXT NOT NULL,
    amount      REAL NOT NULL,
    paid_by     INTEGER NOT NULL,
    created_at  TEXT NOT NULL DEFAULT (datetime('now')),
    FOREIGN KEY (group_id) REFERENCES groups(id) ON DELETE CASCADE,
    FOREIGN KEY (paid_by)  REFERENCES members(id) ON DELETE CASCADE
  );

  -- One row per person sharing an expense. This is the heart of the
  -- data model: it records exactly how much each person owes for each
  -- expense. Balances are computed from these rows, never stored directly.
  CREATE TABLE IF NOT EXISTS expense_splits (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    expense_id  INTEGER NOT NULL,
    member_id   INTEGER NOT NULL,
    amount_owed REAL NOT NULL,
    FOREIGN KEY (expense_id) REFERENCES expenses(id) ON DELETE CASCADE,
    FOREIGN KEY (member_id)  REFERENCES members(id) ON DELETE CASCADE
  );

  -- Records a payment from one member to another to clear debt.
  CREATE TABLE IF NOT EXISTS settlements (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    group_id    INTEGER NOT NULL,
    paid_by     INTEGER NOT NULL,
    paid_to     INTEGER NOT NULL,
    amount      REAL NOT NULL,
    created_at  TEXT NOT NULL DEFAULT (datetime('now')),
    FOREIGN KEY (group_id) REFERENCES groups(id) ON DELETE CASCADE,
    FOREIGN KEY (paid_by)  REFERENCES members(id) ON DELETE CASCADE,
    FOREIGN KEY (paid_to)  REFERENCES members(id) ON DELETE CASCADE
  );
`);

module.exports = db;
