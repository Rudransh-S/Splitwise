// ============================================================
//  SplitWise frontend
//  Talks to the backend REST API and renders the dashboard,
//  group views, and the expense modal (4 split modes).
// ============================================================

// ---- tiny API helper ----
async function api(url, method = "GET", body) {
  const opts = { method, headers: { "Content-Type": "application/json" } };
  if (body) opts.body = JSON.stringify(body);
  const res = await fetch(url, opts);
  if (!res.ok) {
    const err = await res.json().catch(() => ({}));
    toast(err.error || `Error ${res.status}`);
    throw new Error(err.error || res.status);
  }
  return res.json();
}

// ---- formatting / helpers ----
const fmt = (n) => "\u20b9" + Number(n).toLocaleString("en-IN", { minimumFractionDigits: 2, maximumFractionDigits: 2 });
const fmt0 = (n) => "\u20b9" + Math.round(n).toLocaleString("en-IN");
const initials = (name) => name.split(/\s+/).map((w) => w[0]).slice(0, 2).join("").toUpperCase();
const esc = (s) => String(s).replace(/[&<>"]/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c]));

function toast(msg) {
  const t = document.getElementById("toast");
  t.textContent = msg;
  t.hidden = false;
  clearTimeout(toast._t);
  toast._t = setTimeout(() => (t.hidden = true), 2600);
}

// ---- app state ----
let viewer = localStorage_get("viewer") || "";   // name of the person viewing
let people = [];                                   // all distinct member names
let currentView = "dashboard";
let openGroupId = null;

// localStorage is blocked in some embedded contexts; guard it.
function localStorage_get(k) { try { return localStorage.getItem(k); } catch { return null; } }
function localStorage_set(k, v) { try { localStorage.setItem(k, v); } catch {} }

// ============================================================
//  NAV / ROUTING
// ============================================================
document.querySelectorAll(".nav-item").forEach((btn) => {
  btn.onclick = () => {
    document.querySelectorAll(".nav-item").forEach((b) => b.classList.remove("active"));
    btn.classList.add("active");
    const view = btn.dataset.view;
    openGroupId = null;
    if (view === "dashboard") showDashboard();
    else if (view === "groups") showDashboard(true);
    else showPlaceholder(btn.textContent.trim());
  };
});

function setViews(active) {
  ["dashboard", "group", "placeholder"].forEach((v) => {
    document.getElementById("view-" + v).hidden = v !== active;
  });
}

// ============================================================
//  VIEWER PICKER
// ============================================================
async function loadPeople() {
  people = await api("/api/people");
  const sel = document.getElementById("viewerSelect");
  if (people.length === 0) {
    sel.innerHTML = '<option value="">(no members yet)</option>';
    viewer = "";
  } else {
    if (!viewer || !people.includes(viewer)) viewer = people[0];
    sel.innerHTML = people.map((p) => `<option value="${esc(p)}"${p === viewer ? " selected" : ""}>${esc(p)}</option>`).join("");
  }
  document.getElementById("welcomeLine").textContent = viewer ? `Welcome back, ${viewer}` : "Welcome to SplitWise";
}
document.getElementById("viewerSelect").onchange = (e) => {
  viewer = e.target.value;
  localStorage_set("viewer", viewer);
  document.getElementById("welcomeLine").textContent = viewer ? `Welcome back, ${viewer}` : "Welcome to SplitWise";
  if (openGroupId) showGroup(openGroupId);
  else showDashboard();
};

// ============================================================
//  DASHBOARD
// ============================================================
async function showDashboard(groupsFocus = false) {
  currentView = "dashboard";
  setViews("dashboard");
  const el = document.getElementById("view-dashboard");
  const d = await api("/api/dashboard?name=" + encodeURIComponent(viewer));

  const statCards = `
    <div class="summary-grid">
      <div class="stat">
        <div class="stat-top"><div class="stat-ico owed">${svgOwed}</div>
          <div><div class="stat-label">You are owed</div></div></div>
        <div class="stat-value pos">${fmt(d.youAreOwed)}</div>
        <div class="stat-sub">across your groups</div>
      </div>
      <div class="stat">
        <div class="stat-top"><div class="stat-ico owe">${svgOwe}</div>
          <div><div class="stat-label">You owe</div></div></div>
        <div class="stat-value neg">${fmt(d.youOwe)}</div>
        <div class="stat-sub">to others</div>
      </div>
      <div class="stat">
        <div class="stat-top"><div class="stat-ico bal">${svgWallet}</div>
          <div><div class="stat-label">Total balance</div></div></div>
        <div class="stat-value ${d.totalBalance >= 0 ? "pos" : "neg"}">${fmt(Math.abs(d.totalBalance))}</div>
        <div class="stat-sub">${d.totalBalance >= 0 ? "in your favor" : "you owe overall"}</div>
      </div>
      <div class="stat">
        <div class="stat-top"><div class="stat-ico exp">${svgPie}</div>
          <div><div class="stat-label">Total expenses</div></div></div>
        <div class="stat-value">${fmt0(d.totalExpensesThisMonth)}</div>
        <div class="stat-sub">this month</div>
      </div>
    </div>`;

  const groupCards = d.groups.length
    ? d.groups.map((g) => {
        const cls = g.yourBalance > 0 ? "pos" : g.yourBalance < 0 ? "neg" : "";
        const label = !g.inGroup ? "not a member" : g.yourBalance > 0 ? "You are owed" : g.yourBalance < 0 ? "You owe" : "Settled up";
        const val = g.inGroup && g.yourBalance !== 0 ? fmt0(Math.abs(g.yourBalance)) : (g.inGroup ? "\u20b90" : "\u2014");
        return `<div class="group-card" onclick="showGroup(${g.id})">
          <div class="group-thumb">${groupEmoji(g.name)}</div>
          <div class="group-info">
            <div class="group-name">${esc(g.name)}</div>
            <div class="group-meta">${g.memberCount} member${g.memberCount === 1 ? "" : "s"}</div>
            <div class="group-bal-label">${label}</div>
            <div class="group-bal ${cls}">${val}</div>
          </div></div>`;
      }).join("")
    : "";

  const groupsPanel = `
    <div class="panel">
      <div class="panel-head"><span class="panel-title">Your Groups</span></div>
      <div class="panel-body">
        <div class="group-cards">
          ${groupCards}
          <div class="group-card add" onclick="openGroupModal()">
            <div><div class="plus">+</div>New Group</div>
          </div>
        </div>
      </div>
    </div>`;

  const recentRows = d.recentExpenses.length
    ? d.recentExpenses.map((e) => `
        <tr>
          <td>${esc(e.description)}</td>
          <td>${esc(e.groupName)}</td>
          <td><div class="who"><div class="avatar sm">${initials(e.paidByName)}</div>${esc(e.paidByName === viewer ? "You" : e.paidByName)}</div></td>
          <td class="amt">${fmt(e.amount)}</td>
          <td><span class="group-meta">split ${e.splitCount} ways</span></td>
        </tr>`).join("")
    : `<tr><td colspan="5" class="empty">No expenses yet. Add your first one.</td></tr>`;

  const recentPanel = `
    <div class="panel">
      <div class="panel-head"><span class="panel-title">Recent Expenses</span></div>
      <div class="panel-body">
        <table class="tbl">
          <thead><tr><th>Description</th><th>Group</th><th>Paid by</th><th>Amount</th><th>Split</th></tr></thead>
          <tbody>${recentRows}</tbody>
        </table>
      </div>
    </div>`;

  const activityItems = d.recentExpenses.slice(0, 5).map((e) => `
    <div class="feed-item">
      <div class="avatar sm">${initials(e.paidByName)}</div>
      <div class="feed-body">
        <div class="feed-text"><strong>${esc(e.paidByName === viewer ? "You" : e.paidByName)}</strong> added an expense</div>
        <div class="feed-meta">${esc(e.description)} \u00b7 ${esc(e.groupName)}</div>
      </div>
      <div class="feed-amt">${fmt0(e.amount)}</div>
    </div>`).join("") || `<div class="empty">Nothing yet.</div>`;

  const sidePanel = `
    <div>
      <div class="panel">
        <div class="panel-head"><span class="panel-title">Simplify payments</span></div>
        <div class="panel-body">
          <p class="subtle" style="margin-bottom:10px">SplitWise settles balances with the fewest transactions. Open a group to see who should pay whom.</p>
        </div>
      </div>
      <div class="panel">
        <div class="panel-head"><span class="panel-title">Recent Activity</span></div>
        <div class="panel-body">${activityItems}</div>
      </div>
    </div>`;

  el.innerHTML = statCards + `<div class="content-grid"><div>${groupsPanel}${recentPanel}</div>${sidePanel}</div>`;
}

// ============================================================
//  GROUP DETAIL
// ============================================================
async function showGroup(groupId) {
  openGroupId = groupId;
  currentView = "group";
  setViews("group");
  const el = document.getElementById("view-group");
  const s = await api(`/api/groups/${groupId}/state`);
  const nameById = {};
  s.members.forEach((m) => (nameById[m.id] = m.name));
  const groupName = (await api("/api/groups")).find((g) => g.id === groupId)?.name || "Group";

  const membersChips = s.members.map((m) => `<div class="who" style="margin-right:14px"><div class="avatar sm">${initials(m.name)}</div>${esc(m.name)}</div>`).join("");

  const expRows = s.expenses.length
    ? s.expenses.map((e) => `
        <tr>
          <td>${esc(e.description)}</td>
          <td><div class="who"><div class="avatar sm">${initials(nameById[e.paid_by] || "?")}</div>${esc(nameById[e.paid_by] === viewer ? "You" : nameById[e.paid_by])}</div></td>
          <td class="amt">${fmt(e.amount)}</td>
          <td><span class="group-meta">${e.splitAmong.length} people</span></td>
          <td><button class="del-link" onclick="deleteExpense(${e.id})">delete</button></td>
        </tr>`).join("")
    : `<tr><td colspan="5" class="empty">No expenses in this group yet.</td></tr>`;

  const balRows = s.members.map((m) => {
    const v = Math.round((s.balances[m.id] || 0) * 100) / 100;
    const cls = v > 0 ? "pos" : v < 0 ? "neg" : "";
    const txt = v > 0 ? "is owed " + fmt(v) : v < 0 ? "owes " + fmt(-v) : "settled up";
    return `<div class="bal-row"><div class="who"><div class="avatar sm">${initials(m.name)}</div>${esc(m.name)}</div><span class="${cls}" style="font-weight:600">${txt}</span></div>`;
  }).join("") || `<div class="empty">No members.</div>`;

  const settleRows = s.settleUp.length
    ? s.settleUp.map((t) => `
        <div class="settle-row">
          <div class="who">
            <span class="pill neg">${esc(nameById[t.from])}</span>
            <span style="color:var(--muted-2)">\u2192</span>
            <span class="pill pos">${esc(nameById[t.to])}</span>
          </div>
          <div style="display:flex;align-items:center;gap:10px">
            <span class="amt">${fmt(t.amount)}</span>
            <button class="mini-btn" onclick="settle(${t.from},${t.to},${t.amount})">mark paid</button>
          </div>
        </div>`).join("")
    : `<div class="empty">Everyone is settled up.</div>`;

  el.innerHTML = `
    <button class="back-link" onclick="showDashboard()">\u2190 Back to dashboard</button>
    <div class="topbar" style="margin-bottom:16px">
      <div><h1 class="welcome">${groupEmoji(groupName)} ${esc(groupName)}</h1>
        <div style="display:flex;flex-wrap:wrap;margin-top:8px">${membersChips}</div></div>
      <div class="topbar-right">
        <button class="btn-ghost" id="addMemberInline">+ Add member</button>
        <button class="btn-primary" onclick="openExpenseModal(${groupId})">+ New Expense</button>
      </div>
    </div>
    <div class="content-grid">
      <div>
        <div class="panel">
          <div class="panel-head"><span class="panel-title">Expenses</span></div>
          <div class="panel-body">
            <table class="tbl">
              <thead><tr><th>Description</th><th>Paid by</th><th>Amount</th><th>Split</th><th></th></tr></thead>
              <tbody>${expRows}</tbody>
            </table>
          </div>
        </div>
        <div class="panel">
          <div class="panel-head"><span class="panel-title">Settle up</span><span class="group-meta">minimum transactions</span></div>
          <div class="panel-body">${settleRows}</div>
        </div>
      </div>
      <div class="panel">
        <div class="panel-head"><span class="panel-title">Balances</span></div>
        <div class="panel-body">${balRows}</div>
      </div>
    </div>`;

  document.getElementById("addMemberInline").onclick = async () => {
    const name = prompt("New member name:");
    if (!name || !name.trim()) return;
    await api(`/api/groups/${groupId}/members`, "POST", { name: name.trim() });
    await loadPeople();
    showGroup(groupId);
  };
}

async function deleteExpense(id) {
  await api(`/api/expenses/${id}`, "DELETE");
  toast("Expense deleted");
  showGroup(openGroupId);
}

async function settle(paidBy, paidTo, amount) {
  await api(`/api/groups/${openGroupId}/settlements`, "POST", { paidBy, paidTo, amount });
  toast("Payment recorded");
  showGroup(openGroupId);
}

// ============================================================
//  PLACEHOLDER PAGES
// ============================================================
function showPlaceholder(title) {
  currentView = "placeholder";
  setViews("placeholder");
  document.getElementById("view-placeholder").innerHTML = `
    <div class="panel">
      <div class="panel-body" style="padding:60px 20px;text-align:center">
        <div style="font-size:34px;margin-bottom:12px">${svgSpark}</div>
        <div class="panel-title" style="margin-bottom:6px">${esc(title)}</div>
        <p class="subtle">This section is coming soon. The core expense-splitting features live on the Dashboard.</p>
      </div>
    </div>`;
}

// ============================================================
//  EXPENSE MODAL (4 split modes)
// ============================================================
let modalGroupId = null;
let modalMembers = [];

async function openExpenseModal(groupId) {
  // If no group chosen (from top bar), default to the first group.
  const groups = await api("/api/groups");
  if (groups.length === 0) { toast("Create a group first"); openGroupModal(); return; }
  modalGroupId = groupId || openGroupId || groups[0].id;

  const gSel = document.getElementById("mGroup");
  gSel.innerHTML = groups.map((g) => `<option value="${g.id}"${g.id === modalGroupId ? " selected" : ""}>${esc(g.name)}</option>`).join("");
  gSel.onchange = async () => { modalGroupId = Number(gSel.value); await loadModalMembers(); };

  await loadModalMembers();
  document.getElementById("mDesc").value = "";
  document.getElementById("mAmount").value = "";
  document.getElementById("mSplitType").value = "equal";
  document.getElementById("expenseModal").hidden = false;
  renderSplitRows();
}

async function loadModalMembers() {
  const s = await api(`/api/groups/${modalGroupId}/state`);
  modalMembers = s.members;
  document.getElementById("mPayer").innerHTML = modalMembers.map((m) => `<option value="${m.id}">${esc(m.name)}</option>`).join("");
  renderSplitRows();
}

document.getElementById("mSplitType").onchange = renderSplitRows;
document.getElementById("mAmount").addEventListener("input", updateSplitHint);

function renderSplitRows() {
  const mode = document.getElementById("mSplitType").value;
  const box = document.getElementById("mSplitInputs");
  box.innerHTML = modalMembers.map((m) => {
    const av = `<div class="avatar sm">${initials(m.name)}</div>`;
    if (mode === "equal")
      return `<div class="split-line"><span class="name">${av}${esc(m.name)}</span><input type="checkbox" class="sp-eq" data-id="${m.id}" checked></div>`;
    if (mode === "exact")
      return `<div class="split-line"><span class="name">${av}${esc(m.name)}</span><span style="display:flex;align-items:center;gap:6px"><span class="suffix">\u20b9</span><input type="number" class="sp-amt" data-id="${m.id}" min="0" step="0.01" placeholder="0" oninput="updateSplitHint()"></span></div>`;
    if (mode === "percent")
      return `<div class="split-line"><span class="name">${av}${esc(m.name)}</span><span style="display:flex;align-items:center;gap:6px"><input type="number" class="sp-pct" data-id="${m.id}" min="0" step="0.1" placeholder="0" oninput="updateSplitHint()"><span class="suffix">%</span></span></div>`;
    // shares
    return `<div class="split-line"><span class="name">${av}${esc(m.name)}</span><span style="display:flex;align-items:center;gap:6px"><input type="number" class="sp-sh" data-id="${m.id}" min="0" step="1" value="1" oninput="updateSplitHint()"><span class="suffix">share(s)</span></span></div>`;
  }).join("");
  updateSplitHint();
}

function updateSplitHint() {
  const mode = document.getElementById("mSplitType").value;
  const amount = parseFloat(document.getElementById("mAmount").value) || 0;
  const hint = document.getElementById("mSplitHint");
  hint.className = "split-hint";

  if (mode === "equal") {
    const n = document.querySelectorAll(".sp-eq:checked").length;
    hint.textContent = n ? `${fmt(amount / (n || 1))} each (${n} people)` : "Select at least one person";
  } else if (mode === "exact") {
    let sum = 0; document.querySelectorAll(".sp-amt").forEach((i) => (sum += parseFloat(i.value) || 0));
    const left = Math.round((amount - sum) * 100) / 100;
    if (!amount) { hint.textContent = "Enter the total amount first"; return; }
    hint.textContent = `${fmt(sum)} of ${fmt(amount)} assigned \u00b7 ${fmt(left)} left`;
    hint.classList.add(Math.abs(left) < 0.01 ? "ok" : "bad");
  } else if (mode === "percent") {
    let sum = 0; document.querySelectorAll(".sp-pct").forEach((i) => (sum += parseFloat(i.value) || 0));
    hint.textContent = `${sum}% of 100% assigned`;
    hint.classList.add(Math.abs(sum - 100) < 0.01 ? "ok" : "bad");
  } else {
    let sum = 0; document.querySelectorAll(".sp-sh").forEach((i) => (sum += parseFloat(i.value) || 0));
    const per = sum > 0 ? amount / sum : 0;
    hint.textContent = sum ? `${sum} shares \u00b7 ${fmt(per)} per share` : "Add some shares";
  }
}

function closeExpenseModal() { document.getElementById("expenseModal").hidden = true; }
document.getElementById("closeModal").onclick = closeExpenseModal;
document.getElementById("cancelExpense").onclick = closeExpenseModal;
document.getElementById("newExpenseBtn").onclick = () => openExpenseModal(openGroupId);

document.getElementById("saveExpense").onclick = async () => {
  const description = document.getElementById("mDesc").value.trim();
  const amount = parseFloat(document.getElementById("mAmount").value);
  const paidBy = Number(document.getElementById("mPayer").value);
  const splitType = document.getElementById("mSplitType").value;
  if (!description || !amount || amount <= 0 || !paidBy) { toast("Fill in description, amount and payer"); return; }

  const payload = { description, amount, paidBy, splitType };
  if (splitType === "equal") {
    payload.splitAmong = Array.from(document.querySelectorAll(".sp-eq:checked")).map((c) => Number(c.dataset.id));
    if (!payload.splitAmong.length) { toast("Select at least one person"); return; }
  } else if (splitType === "exact") {
    payload.splits = Array.from(document.querySelectorAll(".sp-amt")).map((i) => ({ memberId: Number(i.dataset.id), amount: parseFloat(i.value) || 0 })).filter((s) => s.amount > 0);
  } else if (splitType === "percent") {
    payload.splits = Array.from(document.querySelectorAll(".sp-pct")).map((i) => ({ memberId: Number(i.dataset.id), percent: parseFloat(i.value) || 0 })).filter((s) => s.percent > 0);
  } else {
    payload.splits = Array.from(document.querySelectorAll(".sp-sh")).map((i) => ({ memberId: Number(i.dataset.id), shares: parseFloat(i.value) || 0 })).filter((s) => s.shares > 0);
  }

  await api(`/api/groups/${modalGroupId}/expenses`, "POST", payload);
  closeExpenseModal();
  toast("Expense added");
  if (openGroupId === modalGroupId) showGroup(modalGroupId);
  else showDashboard();
};

// ============================================================
//  NEW GROUP MODAL
// ============================================================
function openGroupModal() {
  document.getElementById("gName").value = "";
  document.getElementById("gMembers").value = "";
  document.getElementById("groupModal").hidden = false;
}
function closeGroupModal() { document.getElementById("groupModal").hidden = true; }
document.getElementById("closeGroupModal").onclick = closeGroupModal;
document.getElementById("cancelGroup").onclick = closeGroupModal;

document.getElementById("saveGroup").onclick = async () => {
  const name = document.getElementById("gName").value.trim();
  if (!name) { toast("Enter a group name"); return; }
  const memberNames = document.getElementById("gMembers").value.split("\n").map((s) => s.trim()).filter(Boolean);
  const group = await api("/api/groups", "POST", { name });
  for (const mn of memberNames) {
    await api(`/api/groups/${group.id}/members`, "POST", { name: mn });
  }
  closeGroupModal();
  await loadPeople();
  toast("Group created");
  showGroup(group.id);
};

// ============================================================
//  MISC
// ============================================================
function groupEmoji(name) {
  const n = name.toLowerCase();
  if (n.includes("trip") || n.includes("goa") || n.includes("beach")) return "\ud83c\udfdd\ufe0f";
  if (n.includes("manali") || n.includes("mountain") || n.includes("trek")) return "\u26f0\ufe0f";
  if (n.includes("flat") || n.includes("home") || n.includes("room") || n.includes("house")) return "\ud83c\udfe0";
  if (n.includes("lunch") || n.includes("dinner") || n.includes("food") || n.includes("office")) return "\ud83c\udf7d\ufe0f";
  return "\ud83d\udcb0";
}

// simple inline SVG glyphs for the stat icons (no external icon lib)
const svgOwed = `<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#059669" stroke-width="2"><path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M22 21v-2a4 4 0 0 0-3-3.87"/></svg>`;
const svgOwe = `<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#ef4444" stroke-width="2"><rect x="2" y="5" width="20" height="14" rx="2"/><line x1="2" y1="10" x2="22" y2="10"/></svg>`;
const svgWallet = `<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#2563eb" stroke-width="2"><path d="M21 12V7H5a2 2 0 0 1 0-4h14v4"/><path d="M3 5v14a2 2 0 0 0 2 2h16v-5"/><path d="M18 12a2 2 0 0 0 0 4h4v-4z"/></svg>`;
const svgPie = `<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#7c3aed" stroke-width="2"><path d="M21.21 15.89A10 10 0 1 1 8 2.83"/><path d="M22 12A10 10 0 0 0 12 2v10z"/></svg>`;
const svgSpark = `<svg width="34" height="34" viewBox="0 0 24 24" fill="none" stroke="#10b981" stroke-width="2"><path d="M12 3v3m0 12v3M3 12h3m12 0h3"/><circle cx="12" cy="12" r="4"/></svg>`;

// map nav icon keywords to small mask SVGs
const NAV_ICONS = {
  home: "M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z",
  groups: "M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2M9 7a4 4 0 1 0 0 .1",
  list: "M8 6h13M8 12h13M8 18h13M3 6h.01M3 12h.01M3 18h.01",
  scale: "M12 3v18M5 7h14l-3 7H8z",
  people: "M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2M9 7a4 4 0 1 0 0 .1",
  clock: "M12 6v6l4 2M12 22a10 10 0 1 0 0-20 10 10 0 0 0 0 20z",
  chart: "M3 3v18h18M7 16v-6M12 16V8M17 16v-3",
  repeat: "M17 1l4 4-4 4M3 11V9a4 4 0 0 1 4-4h14M7 23l-4-4 4-4M21 13v2a4 4 0 0 1-4 4H3",
  gear: "M12 15a3 3 0 1 0 0-6 3 3 0 0 0 0 6zM19 12a7 7 0 0 0-.1-1l2-1.6-2-3.4-2.4 1a7 7 0 0 0-1.7-1L14.5 2h-4l-.3 2.6a7 7 0 0 0-1.7 1l-2.4-1-2 3.4L4 11a7 7 0 0 0 0 2l-2 1.6 2 3.4 2.4-1a7 7 0 0 0 1.7 1l.3 2.6h4l.3-2.6a7 7 0 0 0 1.7-1l2.4 1 2-3.4-2-1.6a7 7 0 0 0 .1-1z",
  help: "M12 22a10 10 0 1 0 0-20 10 10 0 0 0 0 20zM9.1 9a3 3 0 0 1 5.8 1c0 2-3 3-3 3M12 17h.01",
};
document.querySelectorAll(".nav-ico").forEach((el) => {
  const key = el.textContent.trim();
  const path = NAV_ICONS[key] || NAV_ICONS.home;
  const svg = `<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24' fill='none' stroke='black' stroke-width='2' stroke-linecap='round' stroke-linejoin='round'><path d='${path}'/></svg>`;
  const uri = "url(\"data:image/svg+xml;utf8," + encodeURIComponent(svg) + "\")";
  el.style.webkitMaskImage = uri;
  el.style.maskImage = uri;
  el.textContent = "";
});

// ============================================================
//  BOOT
// ============================================================
(async function init() {
  await loadPeople();
  await showDashboard();
})();
