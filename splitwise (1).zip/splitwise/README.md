# Splitwise Clone

A simple full-stack expense-splitting app. Create groups, add members and
expenses, see who owes whom, and settle up with the minimum number of payments.

## Stack

- **Backend:** Node.js + Express (REST API)
- **Database:** SQLite via Node's built-in `node:sqlite` (a single file, no setup)
- **Frontend:** plain HTML + CSS + JavaScript (no build step)

## Requirements

- Node.js version 22.5 or newer (needed for the built-in SQLite).
  Check yours with: `node --version`

## The interface

The app opens on a **dashboard** with a sidebar, summary cards (you are owed,
you owe, total balance, expenses this month), your groups, and a recent
activity feed - all wired to the real backend.

Since there is no login yet, use the **"Viewing as"** dropdown in the top right
to pick which person you are. The dashboard totals ("you are owed" / "you owe")
are then calculated for that person across all their groups. Click any group
card to open it and add expenses, see balances, and settle up.

The sidebar items Friends, Statistics, Recurring Expenses, Settings, and Help
are placeholder pages for now.

## Run it

```bash
npm install     # installs Express (the only dependency)
npm start       # starts the server
```

Then open your browser to: http://localhost:3000

The database file `backend/splitwise.db` is created automatically the first
time you run it, and your data persists across restarts.

## Project structure

```
splitwise/
├── package.json          # dependencies + start script
├── backend/
│   ├── server.js         # Express server + REST API routes
│   ├── db.js             # database setup + table schema
│   └── balances.js       # balance calculation + debt simplification
└── public/               # the frontend (served by the backend)
    ├── index.html
    ├── style.css
    └── app.js
```

## How it works

1. The frontend (`public/`) makes HTTP requests to the backend API.
2. The backend (`backend/server.js`) handles those requests and reads/writes
   the SQLite database.
3. **Balances are never stored** - they're computed on demand from the
   expenses, splits, and settlements. This keeps the data consistent.

### The data model

- `groups` - a group of people sharing expenses
- `members` - people in a group
- `expenses` - who paid, how much, for what
- `expense_splits` - one row per person sharing each expense (the key table)
- `settlements` - records of payments made to clear debt

### The API

| Method | URL | Does |
|--------|-----|------|
| POST | `/api/groups` | create a group |
| GET | `/api/groups` | list groups |
| POST | `/api/groups/:id/members` | add a member |
| POST | `/api/groups/:id/expenses` | add an expense |
| DELETE | `/api/expenses/:id` | delete an expense |
| POST | `/api/groups/:id/settlements` | record a payment |
| GET | `/api/groups/:id/state` | everything: members, expenses, balances, settle-up |

## Note

When it starts you'll see a warning that SQLite is "experimental" - that's
normal and harmless. It just means Node's built-in SQLite is a newer feature.

### Splitting an expense

When adding an expense you can choose how it's split:

- **Equally** - divided evenly among the people you tick.
- **By exact amounts** - type exactly what each person owes. The amounts
  must add up to the total (a live hint shows how much is left to assign).
- **By percentage** - assign each person a percentage; they must total 100%.
- **By shares** - give each person a number of shares. Someone with 2 shares
  owes twice as much as someone with 1 share. Useful when, say, two people
  shared a room and one person had it to themselves.

All three end up stored the same way: as per-person rows in the
`expense_splits` table. Only the way the amounts are *calculated* differs.

## Next steps to explore

- Add user login so people only see their own groups
- Add an "export to Excel" button
- Deploy it online (Render, Railway, and Fly.io all work well)
